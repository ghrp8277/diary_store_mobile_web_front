<template>
  <div class="container">
    <div class="emoji-info">
      <div class="img-container">
        <img src="@/assets/logo.png" alt="" />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed } from '@vue/composition-api';
export default defineComponent({
  name: 'EmojiDetail',
});
</script>

<style scoped lang="scss"></style>

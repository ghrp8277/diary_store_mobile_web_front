import { State } from './state';
import moment from 'moment';

const getters = {};

type Getters = typeof getters;

export { getters, Getters };

export interface Category {
  category: string;
}

import { Product } from './product';

export interface Favorite {
  id: number;
  product: Product;
  username: string;
}

export interface FAQ {
  id: number;
  title: string;
  content: string;
  username: string;
  is_visible: number;
  createdAt: Date;
}

export interface EmojiInfo {
  id: number;
  product_name: string;
  author_name: string;
  category: string;
  tag: string;
  comment: string;
}
